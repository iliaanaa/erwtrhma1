#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include "bank_system.h"

#define PORT 8080

void handle_client(int client_socket) {
    char buffer[1024];
    int n;

    while ((n = read(client_socket, buffer, sizeof(buffer) - 1)) > 0) {
        buffer[n] = '\0';

        char response[1024];
        char command[256];
        int accountNumber1, accountNumber2;
        float amount;

        sscanf(buffer, "%s", command);

        if (strcmp(command, "DISPLAY") == 0) {
            sscanf(buffer, "%*s %d", &accountNumber1);
            float amt = display_amount(accountNumber1);
            snprintf(response, sizeof(response), "%.2f", amt);
        } else if (strcmp(command, "MODIFY") == 0) {
            sscanf(buffer, "%*s %d %f", &accountNumber1, &amount);
            int result = modify_amount(accountNumber1, amount);
           if (result) {
               float newAmount = display_amount(accountNumber1); 
             snprintf(response, sizeof(response), "Amount updated successfully. New balance: %.2f", newAmount);
             } else {
             snprintf(response, sizeof(response), "Failed to update amount.");
    }
        } else if (strcmp(command, "TRANSFER") == 0) {
            sscanf(buffer, "%*s %d %d %f", &accountNumber1, &accountNumber2, &amount);
            int result = transfer_amount(accountNumber1, accountNumber2, amount);
             if (result) {
        float newFromAmount = display_amount(accountNumber1); // Νέο ποσό από λογαριασμό
        float newToAmount = display_amount(accountNumber2);   // Νέο ποσό σε λογαριασμό
        snprintf(response, sizeof(response), 
                 "Transfer successful.\nFrom Account New Balance: %.2f\nTo Account New Balance: %.2f", 
                 newFromAmount, newToAmount);
    } else {
        snprintf(response, sizeof(response), "Transfer failed.");
    }
    
        } else if (strcmp(command, "AVERAGE") == 0) {
            float avg = average_amount();
            snprintf(response, sizeof(response), "Average balance: %.2f", avg);
        } else {
            snprintf(response, sizeof(response), "Invalid command.");
        }

        write(client_socket, response, strlen(response));
    }

    close(client_socket);
}

int main() {
    int server_socket, client_socket;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_addr_len;

    init_departments(); // Initialize the departments

    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    int opt = 1;
    if (setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt))) {
        perror("setsockopt");
        close(server_socket);
        exit(EXIT_FAILURE);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    if (bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        close(server_socket);
        exit(EXIT_FAILURE);
    }

    if (listen(server_socket, 5) < 0) {
        perror("Listen failed");
        close(server_socket);
        exit(EXIT_FAILURE);
    }

    printf("Server started. Listening on port %d...\n", PORT);

    while (1) {
        client_addr_len = sizeof(client_addr);
        client_socket = accept(server_socket, (struct sockaddr *)&client_addr, &client_addr_len);
        if (client_socket < 0) {
            perror("Accept failed");
            continue;
        }

        handle_client(client_socket);
    }

    close(server_socket);
    return 0;
}

