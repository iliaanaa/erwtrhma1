#include "bank_system.h"

Department departments[NUM_DEPARTMENTS];

void init_departments() {
    srand(time(NULL));

    for (int i = 0; i < NUM_DEPARTMENTS; i++) {
        departments[i].record_count = 0;
        for (int j = 0; j < 500; j++) {
            departments[i].records[j].accountNumber = i * 500 + j + 1;
            departments[i].records[j].amount = (float)(rand() % 10000) / 100;
            time_t t = time(NULL);
            struct tm tm = *localtime(&t);
           int n = snprintf(departments[i].records[j].timestamp, sizeof(departments[i].records[j].timestamp),
                     "%04d-%02d-%02d %02d:%02d:%02d", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday,
                     tm.tm_hour, tm.tm_min, tm.tm_sec); //to %04d-%02d-%02d %02d:%02d:%02d exedi 19 xarakthres +to null terminator 
                     //ara to timestampo tha prepei na exei toulaxiiston 20 xrakthres
            departments[i].record_count++;
            if (n >= sizeof(departments[i].records[j].timestamp)) {
             fprintf(stderr, "Timestamp truncated\n");
            }  
        }
    }
}

void generate_load_files(int department_number, const char *filename) {
    FILE *file = fopen(filename, "w");
    if (!file) {
        perror("Failed to open file");
        return;
    }

    for (int i = 0; i < NUM_REQUESTS; i++) {
        int queryType;
        float randPercent = (float)rand() / RAND_MAX;
        if (randPercent < 0.35) {
            queryType = 1; // DISPLAY
        } else if (randPercent < 0.70) {
            queryType = 2; // MODIFY
        } else if (randPercent < 0.95) {
            queryType = 3; // TRANSFER
        } else {
            queryType = 4; // AVERAGE
        }

        int accountNumber = rand() % (NUM_DEPARTMENTS * 500) + 1;
        float amount = (float)(rand() % 10000) / 100;
        int fromAccount = rand() % (NUM_DEPARTMENTS * 500) + 1;
        int toAccount = rand() % (NUM_DEPARTMENTS * 500) + 1;

        if (queryType == 1 || queryType == 2) {
            float prob = (float)rand() / RAND_MAX;
            if (prob < 0.8) {
                accountNumber = department_number * 500 + (rand() % 500) + 1;
            }
        }

        if (queryType == 1) {
            fprintf(file, "%d DISPLAY %d\n", department_number, accountNumber);
        } else if (queryType == 2) {
            fprintf(file, "%d MODIFY %d %f\n", department_number, accountNumber, amount);
        } else if (queryType == 3) {
            fprintf(file, "%d TRANSFER %d %d %f\n", department_number, fromAccount, toAccount, amount);
        } else if (queryType == 4) {
            fprintf(file, "%d AVERAGE\n", department_number);
        }
    }

    fclose(file);
}

float display_amount(int accountNumber) {
    for (int i = 0; i < NUM_DEPARTMENTS; i++) {
        for (int j = 0; j < departments[i].record_count; j++) {
            if (departments[i].records[j].accountNumber == accountNumber) {
                return departments[i].records[j].amount;
            }
        }
    }
    return -1; // Account not found
}

int modify_amount(int accountNumber, float amount) {
    for (int i = 0; i < NUM_DEPARTMENTS; i++) {
        for (int j = 0; j < departments[i].record_count; j++) {
            if (departments[i].records[j].accountNumber == accountNumber) {
                departments[i].records[j].amount += amount;
                return 1; // Success
            }
        }
    }
    return 0; // Account not found
}

int transfer_amount(int fromAccount, int toAccount, float amount) {
    float fromAmount = display_amount(fromAccount);
    if (fromAmount < amount) {
        return 0; // Insufficient funds
    }
    if (modify_amount(fromAccount, -amount) && modify_amount(toAccount, amount)) {
        return 1; // Success
    }
    return 0; // Failure
}

float average_amount() {
    int total_accounts = 0;
    float total_amount = 0.0;
    for (int i = 0; i < NUM_DEPARTMENTS; i++) {
        for (int j = 0; j < departments[i].record_count; j++) {
            total_amount += departments[i].records[j].amount;
            total_accounts++;
        }
    }
    return total_accounts ? total_amount / total_accounts : 0.0;
}
