#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define SERVER_PORT 8080
#define SERVER_ADDRESS "127.0.0.1"

void send_request(const char *request, char *response) {
    int sockfd;
    struct sockaddr_in server_addr;
    char buffer[1024];

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    inet_pton(AF_INET, SERVER_ADDRESS, &server_addr.sin_addr);

    if (connect(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connection to server failed");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    write(sockfd, request, strlen(request));
    int n = read(sockfd, buffer, sizeof(buffer) - 1);
    buffer[n] = '\0';

    strcpy(response, buffer);

    close(sockfd);
}

int main() {
    int choice;
    char response[1024];
    char request[1024];

    while (1) {
        printf("\n1. Display amount for an account number\n");
        printf("2. Add/subtract money from the amount of an account number\n");
        printf("3. Transfer money from one account to another\n");
        printf("4. Display the average of the amounts per account\n");
        printf("0. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        if (choice == 0) {
            break;
        }

        int accountNumber1, accountNumber2;
        float amount;

        switch (choice) {
            case 1:
                printf("Enter account number: ");
                scanf("%d", &accountNumber1);
                snprintf(request, sizeof(request), "DISPLAY %d", accountNumber1);
                send_request(request, response);
                printf("Response: %s\n", response);
                break;
            case 2:
                printf("Enter account number: ");
                scanf("%d", &accountNumber1);
                printf("Enter amount to add/subtract: ");
                scanf("%f", &amount);
                snprintf(request, sizeof(request), "MODIFY %d %f", accountNumber1, amount);
                send_request(request, response);
                printf("Response: %s\n", response);
                break;
            case 3:
                printf("Enter account number to transfer from: ");
                scanf("%d", &accountNumber1);
                printf("Enter account number to transfer to: ");
                scanf("%d", &accountNumber2);
                printf("Enter amount to transfer: ");
                scanf("%f", &amount);
                snprintf(request, sizeof(request), "TRANSFER %d %d %f", accountNumber1, accountNumber2, amount);
                send_request(request, response);
                printf("Response: %s\n", response);
                break;
            case 4:
                snprintf(request, sizeof(request), "AVERAGE");
                send_request(request, response);
                printf("Response: %s\n", response);
                break;
            default:
                printf("Invalid choice. Please enter a valid option.\n");
        }
    }

    return 0;
}
