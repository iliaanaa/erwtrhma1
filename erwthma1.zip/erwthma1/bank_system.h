#ifndef BANK_SYSTEM_H
#define BANK_SYSTEM_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define MAX_RECORDS 1000
#define NUM_DEPARTMENTS 2
#define NUM_REQUESTS 300000

typedef struct {
    int accountNumber;
    float amount;
    char timestamp[50];
} Record;

typedef struct {
    Record records[MAX_RECORDS];
    int record_count;
} Department;

extern Department departments[NUM_DEPARTMENTS];

void init_departments();
void generate_load_files(int department_number, const char *filename);
float display_amount(int accountNumber);
int modify_amount(int accountNumber, float amount);
int transfer_amount(int fromAccount, int toAccount, float amount);
float average_amount();

#endif // BANK_SYSTEM_H
